# base.py
👋 Hi there,

This module is to simplify the access to my utility functions. Feel free to use it and suggest improvements 🤝


## Last Update - 1st of September 2023
First commit

## Some notes
We shall present some cool functions here.

**Dependencies**
If not already installed, this module will install the following packages and their dependencies:
* tiktoken - to calculate the number of tokens
* openai - for embedding, chat-gpt-3.5 and chat-gpt-4
* request


